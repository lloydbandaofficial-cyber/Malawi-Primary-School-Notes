# Primary School Notes — modernized rebuild

This is a source reconstruction of the supplied APK `com.primary.noel`.

## Open/build

1. Open this folder in Android Studio.
2. Install Android SDK Platform 36 and the Android 36 build tools.
3. Let Android Studio sync Gradle.
4. Build `app` -> `assembleDebug`.
5. Install `app/build/outputs/apk/debug/app-debug.apk`.

The project uses:
- Android Gradle Plugin 8.9.2
- compileSdk 36
- targetSdk 36
- minSdk 23
- Java 17

A Gradle wrapper JAR is intentionally not bundled because the analysis environment had no Gradle installation and no network access from which to obtain it. Android Studio can use its configured Gradle distribution, or `gradle wrapper` can be run once on a machine with Gradle installed.

## Important signing note

The reconstructed APK will be signed with a new debug/release key. It cannot update the original installed APK unless the original private signing key is available. Uninstall the old app first if Android reports a signature mismatch.

## Compatibility notes

The original app targeted API 22. Android 15 refuses installation of packages targeting below API 24. The rebuild targets API 36 and updates the WebView/permission/back-navigation/storage behavior.

The educational HTML and media content in `app/src/main/assets` was copied from the supplied APK and is intentionally not redesigned.
