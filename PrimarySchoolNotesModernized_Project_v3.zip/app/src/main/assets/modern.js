/* Primary School Notes - theme toggle, table wrapping, back-to-top. */
(function () {
  var root = document.documentElement, KEY = 'psn-theme';
  try {
    var saved = localStorage.getItem(KEY);
    if (saved === 'dark' || saved === 'light') root.setAttribute('data-theme', saved);
  } catch (e) {}

  function isDark() {
    var t = root.getAttribute('data-theme');
    if (t) return t === 'dark';
    return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  }
  function ready(fn) {
    if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn);
  }
  var SUN = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
  var MOON = '<svg viewBox="0 0 24 24"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
  var UP = '<svg viewBox="0 0 24 24"><path d="M6 15l6-6 6 6"/></svg>';

  ready(function () {
    // Let wide tables scroll sideways instead of breaking the page.
    var tables = document.querySelectorAll('table');
    for (var i = 0; i < tables.length; i++) {
      var t = tables[i];
      if (t.parentElement && (t.parentElement.classList.contains('tbl-wrap') ||
          (t.parentElement.closest && t.parentElement.closest('table')))) continue;
      var w = document.createElement('div');
      w.className = 'tbl-wrap';
      t.parentNode.insertBefore(w, t);
      w.appendChild(t);
    }

    var toggle = document.createElement('button');
    toggle.className = 'fab fab-theme';
    toggle.type = 'button';
    function paint() {
      toggle.innerHTML = isDark() ? SUN : MOON;
      toggle.setAttribute('aria-label', isDark() ? 'Switch to light mode' : 'Switch to dark mode');
    }
    toggle.addEventListener('click', function () {
      var next = isDark() ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem(KEY, next); } catch (e) {}
      paint();
    });
    paint();
    document.body.appendChild(toggle);

    var top = document.createElement('button');
    top.className = 'fab fab-top';
    top.type = 'button';
    top.innerHTML = UP;
    top.setAttribute('aria-label', 'Back to top');
    top.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
    document.body.appendChild(top);
    window.addEventListener('scroll', function () {
      top.classList.toggle('show', (window.pageYOffset || root.scrollTop) > 700);
    }, { passive: true });
  });
})();
