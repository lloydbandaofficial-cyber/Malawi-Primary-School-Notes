# Primary School Notes — APK forensic analysis and modernization

## Artifact
- Input: `base.apk`
- SHA-256: `1e8bf79aa02fc00214c4e902a732aa92078cb1cc92c4ea662` (see note: full hash is recorded below)
- APK size: 14,784,738 bytes
- DEX SHA-256: `e24bf7694723863ca0fc183c89c1873ae20061f2b04d820d4702dda35b1f354c`
- Manifest SHA-256: `521e785bb31b472c47984534a343879ea9a4191568cea147632c7d249753c4e7`
- `classes.dex`: Dalvik DEX version 035
- One DEX file, 15 class definitions.

> Correct full APK SHA-256: `1e8bf79aa02fc00214c4e902a732aa92078cb1cc92a98aa9adc35bf743d40878`

## Identity / SDK
- Package/application ID: `com.primary.noel`
- Application label: `Primary School Notes`
- Version name: `1.0`
- Version code: `1`
- Original `minSdkVersion`: 11 (Android 3.0)
- Original `targetSdkVersion`: 22 (Android 5.1)
- Manifest platform build version: 22 / `5.1.1-1819727`
- Compile SDK is not stored as a direct Gradle value in an APK; the manifest's platform build version 22 strongly indicates the original build used Android platform/API 22.
- Reconstructed project: `minSdk 23`, `targetSdk 36`, `compileSdk 36`.

Android 14 blocks installation of APKs targeting below API 23; Android 15 raises the minimum installable target to API 24. This APK targets API 22, so its target level alone is sufficient to explain installation failure on Android 14/15+ devices. Android's current documentation also recommends testing and addressing compatibility changes before targeting the newest API. 

## Manifest
Declared permissions:
- INTERNET
- ACCESS_NETWORK_STATE
- ACCESS_FINE_LOCATION
- CAMERA
- READ_EXTERNAL_STORAGE
- WRITE_EXTERNAL_STORAGE
- VIBRATE

The rebuild keeps the permissions that have a functional purpose and modernizes storage handling. Legacy external-storage permission is limited to API 28 and below. READ_EXTERNAL_STORAGE is not retained because the rebuilt file chooser uses the system picker/SAF.

Application:
- `allowBackup=true`
- hardware acceleration enabled
- one launcher activity: `com.primary.noel.MainActivity`
- no services
- no broadcast receivers
- no content providers
- no deep-link intent filters
- only MAIN/LAUNCHER intent filter
- original activity was fixed to `screenOrientation=2`; the rebuild leaves orientation unspecified to avoid unnecessary modern-device restrictions while preserving normal app behavior.

## Architecture
No `lib/<abi>/*.so` files were found.
Therefore:
- no native ABI compatibility problem was detected;
- no 32-bit/64-bit native library migration is required;
- the app is Java/Dalvik bytecode plus resources/assets.

## Application architecture
The app is a WebView wrapper, not a large native UI application.

DEX references include:
- `android.webkit.WebView`
- `WebSettings`
- `WebChromeClient`
- `WebViewClient`
- file chooser support
- geolocation support
- WebView permission requests
- download listener
- cookies
- fullscreen/custom-view video handling
- JavaScript interface support.

The DEX contains `MainActivity` and 14 related inner/helper classes. The original WebView code uses the object name `Website2APK` for its JavaScript interface.

## Bundled content
The APK contains approximately 648 `assets/` entries (including nested content) and roughly 16 MB of uncompressed asset data.

Important bundled pages:
- `assets/index.html`
- `assets/index2.html`
- `assets/Standard 5.html`
- `assets/Standard 6.html`
- `assets/Standard 7).html`
- `assets/Standard 8.html`
- `assets/404r.html`

The four main study-note HTML files are approximately:
- Standard 5: 255 KB
- Standard 6: 454 KB
- Standard 7: 656 KB
- Standard 8: 507 KB

The pages contain their images, CSS/JS and other local resources inside the APK. This means the core educational content is recoverable without the original server or source repository.

The home page explicitly identifies the content as **MALAWI PRIMARY SCHOOLS STUDY NOTES** and credits Noel K Mhone of Chibavi Community Day Secondary School.

## External/network references
The bundled HTML is primarily offline/local. External references found include several old HTTP links in Standard 7 and a `mailto:` link.

The modernization does not enable unrestricted cleartext HTTP inside the WebView. HTTP/app-specific schemes are handed to external Android handlers; HTTPS can remain in the WebView. This avoids weakening network security merely to preserve old link behavior.

## Original menus/features recovered
The original resource table contains:
- Exit
- About
- Primary School Notes
- share text
- developer/about text
- `DefaultCache`

The original activity/menu bytecode includes:
- Share
- About dialog
- Exit confirmation
- WebView back navigation
- WebView downloads
- file chooser
- geolocation permission flow
- camera permission flow
- fullscreen/custom video
- WebView error page
- external URL handling
- JavaScript interface methods including `exitApp`, `askEnableGPS`, `openExternal`, `rateUs`, `shareIntent`, `showAboutDialog`, and `showToast`.

The rebuild preserves the documented/observable application workflows. The unused device-ID JavaScript method is not exposed because the bundled HTML does not require it and exposing a device identifier would unnecessarily weaken privacy.

## Signing
The original APK is signed with a v1/JAR-style certificate. No APK Signing Block (`APK Sig Block 42`) was found, so no v2/v3 signing block was detected.

Certificate:
- Subject: Pravesh Agrawal / Goyal Traders
- SHA-1: `6D:2A:A3:6C:37:0D:8B:61:56:DB:A7:07:98:A8:C6:C7:28:26:54:04`
- SHA-256: `0C:BC:1E:3C:76:42:C5:63:18:67:39:34:4C:D3:13:7B:E9:90:CC:19:43:CB:48:75:E3:CB:68:73:19:8E:D2:66`

This matters for upgrades: the rebuilt APK cannot replace the installed original as an update unless it is signed with the same private key. The original private signing key was not present in the APK and cannot be recovered from the certificate.

## Why simply changing targetSdk is insufficient
The original app relies on old WebView patterns:
- legacy file-URL access settings;
- legacy storage permissions;
- old permission handling;
- old WebView/cookie/cache APIs;
- deprecated back handling;
- old fullscreen/file chooser behavior;
- cleartext HTTP references in bundled content;
- old SDK target behavior.

Changing only `targetSdkVersion` would make installation possible on newer Android versions but would not properly modernize these behaviors.

## Rebuild changes
The supplied project:
1. Targets Android 16/API 36 and compiles against API 36.
2. Uses a modern Android Gradle Plugin configuration.
3. Keeps the original package ID and version.
4. Preserves all bundled educational assets unchanged.
5. Uses a modern WebView configuration.
6. Disables unsafe `file://` universal/file-to-file URL access.
7. Uses runtime permissions for camera/location.
8. Uses the modern system file picker for WebView file selection.
9. Handles WebView downloads with DownloadManager.
10. Handles fullscreen WebView video.
11. Uses modern back navigation on Android 13+ while retaining a fallback for older supported versions.
12. Does not request notification permission because the original app has no notification feature.
13. Does not retain unnecessary READ_EXTERNAL_STORAGE.
14. Does not add Firebase or other external services.
15. Does not add native libraries.

## Testing limitation
This environment contains the APK but does not contain an Android SDK/build-tools/Gradle installation. Internet access is also unavailable to download those build tools. Therefore the project has been prepared for Android Studio/Gradle compilation, but an APK could not honestly be claimed as compiled or device-tested here.

The project should be opened in a current Android Studio installation with Android SDK 36 and the matching Gradle/AGP components installed. After Gradle sync, build a debug APK and install it on the target Android device/emulator.

## Asset integrity limitation
Static inspection found several local references in the original HTML that point to files not present in the APK, including:
- `themes/2/js-image-slider.css`
- `themes/2/js-image-slider.js`
- `generic.css`
- one old Windows absolute file path in Standard 7
- a malformed `cumi.home.blog` link.

These were not fabricated in the rebuild. The main study-note pages and their bundled images remain intact, but the missing slider support files cannot be faithfully reconstructed from the APK alone.

## What was and was not recovered
Recovered:
- package identity
- manifest behavior
- SDK levels
- resources
- menu
- UI structure
- WebView architecture
- bundled HTML/CSS/JS/images
- observable JavaScript interface surface
- external URL patterns
- permissions
- fullscreen/download/file-picker/geolocation behavior
- signing certificate metadata

Not recovered:
- original Java source code
- original private signing key
- any server-side source code
- any unavailable external service implementation.

The Java source in the project is therefore a clean functional reconstruction based on the APK's observable behavior, not a claim that the original source code was recovered.
